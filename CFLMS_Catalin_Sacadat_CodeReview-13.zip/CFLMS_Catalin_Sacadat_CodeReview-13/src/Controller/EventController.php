<?php
namespace App\Controller;

// We need to import Response, Route, Request and Controller if we want to use them
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController ;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\EventInformation;

class EventController extends AbstractController
{
  /**
    * @Route("/", name="home_page")
    */
  public function homePageAction()
  {
      return $this->render('event/home.html.twig');
  }

   /**
    * @Route("/index", name="index_page")
    */
   public function indexAction()
   {
    $events = $this->getDoctrine()->getRepository('App:EventInformation')->findAll();
        return $this->render('event/index.html.twig', array('event_information'=>$events));
   }

   /**
    * @Route("/admin", name="admin_page")
    */
   public function adminAction()
   {
    $events = $this->getDoctrine()->getRepository('App:EventInformation')->findAll();
        return $this->render('event/admin.html.twig', array('event_information'=>$events));
   }

    /**
    * @Route("/view/{id}", name="view_page")
    */
   public function viewAction($id)
   {
      $em = $this->getDoctrine()->getManager();
      $events = $em->getRepository('App:EventInformation')->find($id);
      //$events = $this->getDoctrine()->getRepository('App:EventInformation')->find($id);
      return $this->render('event/view.html.twig', array('event_information'=>$events));
   }

    /**
    * @Route("/add", name="add_page")
    */
   public  function addAction(Request $request)
   {
              // Here we create an object from the class that we made
       $event = new EventInformation;
/* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
       $form = $this->createFormBuilder($event)
        ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px;margin-left:15px')))
        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('imgage', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('postal_code', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', ChoiceType::class, array('choices'=>array('Musical'=>'Musical', 'Sports'=>'Sports', 'Movie'=>'Movie'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
        ->add('event_date', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('event_time', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('add', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);
       

       /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
       if($form->isSubmitted() && $form->isValid()){
           //fetching data

           // taking the data from the inputs by the name of the inputs then getData() function
           $name = $form['name']->getData();
           $description = $form['description']->getData();
           $imgage = $form['imgage']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $phone = $form['phone']->getData();
           $address = $form['address']->getData();
           $city = $form['city']->getData();
           $postal_code = $form['postal_code']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           $event_date = $form['event_date']->getData();
           $event_time = $form['event_time']->getData();

/* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
           $event->setName($name);
           $event->setDescription($description);
           $event->setImgage($imgage);
           $event->setCapacity($capacity);
           $event->setEmail($email);
           $event->setPhone($phone);
           $event->setAddress($address);
           $event->setCity($city);
           $event->setPostalCode($postal_code);
           $event->setUrl($url);
           $event->setType($type);
           $event->setEventDate($event_date);
           $event->setEventTime($event_time);
           $em = $this->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'event Added'
                   );
           return $this->redirectToRoute('add_page');
       }
/* now to make the form we will add this line form->createView() and now you can see the form in create.html.twig file  */
       return $this->render('event/add.html.twig', array('form' => $form->createView()));
   }

    /**
    * @Route("/edit/{id}", name="edit_page")
    */
   public  function editAction($id, Request $request)
   {
       
   $event = $this->getDoctrine()->getRepository('App:EventInformation')->find($id);

           $event->setName($event->getName());
           $event->setDescription($event->getDescription());
           $event->setImgage($event->getImgage());
           $event->setCapacity($event->getCapacity());
           $event->setEmail($event->getEmail());
           $event->setPhone($event->getPhone());
           $event->setAddress($event->getAddress());
           $event->setCity($event->getCity());
           $event->setPostalCode($event->getPostalCode());
           $event->setUrl($event->getUrl());
           $event->setType($event->getType());
           $event->setEventDate($event->getEventDate());
           $event->setEventTime($event->getEventTime());

      $form = $this->createFormBuilder($event)
        ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px;margin-left:15px')))
        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('imgage', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('postal_code', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', ChoiceType::class, array('choices'=>array('Musical'=>'Musical', 'Sports'=>'Sports', 'Movie'=>'Movie'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
        ->add('event_date', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('event_time', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('add', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);

       if($form->isSubmitted() && $form->isValid()){
           //fetching data
           $name = $form['name']->getData();
           $description = $form['description']->getData();
           $imgage = $form['imgage']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $phone = $form['phone']->getData();
           $address = $form['address']->getData();
           $city = $form['city']->getData();
           $postal_code = $form['postal_code']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           $event_date = $form['event_date']->getData();
           $event_time = $form['event_time']->getData();
           $em = $this->getDoctrine()->getManager();
           $todo = $em->getRepository('App:EventInformation')->find($id);
           
           $event->setName($name);
           $event->setDescription($description);
           $event->setImgage($imgage);
           $event->setCapacity($capacity);
           $event->setEmail($email);
           $event->setPhone($phone);
           $event->setAddress($address);
           $event->setCity($city);
           $event->setPostalCode($postal_code);
           $event->setUrl($url);
           $event->setType($type);
           $event->setEventDate($event_date);
           $event->setEventTime($event_time);
       
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Updated'
                   );
           return $this->redirectToRoute('admin_page');
       }
      return $this->render('event/edit.html.twig', array('event_information' => $event, 'form' => $form->createView()));
   }

    /**
    * @Route("/delete/{id}", name="delete_page")
    */
   public  function deleteAction($id, Request $request)
   {
      $event = $this->getDoctrine()->getRepository('App:EventInformation')->find($id);

           $event->setName($event->getName());
           $event->setDescription($event->getDescription());
           $event->setImgage($event->getImgage());
           $event->setCapacity($event->getCapacity());
           $event->setEmail($event->getEmail());
           $event->setPhone($event->getPhone());
           $event->setAddress($event->getAddress());
           $event->setCity($event->getCity());
           $event->setPostalCode($event->getPostalCode());
           $event->setUrl($event->getUrl());
           $event->setType($event->getType());
           $event->setEventDate($event->getEventDate());
           $event->setEventTime($event->getEventTime());

      $form = $this->createFormBuilder($event)
        ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px;margin-left:15px')))
        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('imgage', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('postal_code', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('type', ChoiceType::class, array('choices'=>array('Musical'=>'Musical', 'Sports'=>'Sports', 'Movie'=>'Movie'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
        ->add('event_date', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('event_time', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('add', SubmitType::class, array('label'=> 'Delete Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       ->getForm();
       $form->handleRequest($request);

       if($form->isSubmitted() && $form->isValid()){
           //fetching data
           $name = $form['name']->getData();
           $description = $form['description']->getData();
           $imgage = $form['imgage']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $phone = $form['phone']->getData();
           $address = $form['address']->getData();
           $city = $form['city']->getData();
           $postal_code = $form['postal_code']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           $event_date = $form['event_date']->getData();
           $event_time = $form['event_time']->getData();
           $em = $this->getDoctrine()->getManager();
           $todo = $em->getRepository('App:EventInformation')->find($id);
           
           $event->setName($name);
           $event->setDescription($description);
           $event->setImgage($imgage);
           $event->setCapacity($capacity);
           $event->setEmail($email);
           $event->setPhone($phone);
           $event->setAddress($address);
           $event->setCity($city);
           $event->setPostalCode($postal_code);
           $event->setUrl($url);
           $event->setType($type);
           $event->setEventDate($event_date);
           $event->setEventTime($event_time);
       
           $em->remove($event);
           $em->flush();
           $this->addFlash(
             'notice',
             'Event Removed'
             );
           return $this->redirectToRoute('admin_page');
       }

      return $this->render('event/edit.html.twig', array('event_information' => $event, 'form' => $form->createView()));

   }
}
?>